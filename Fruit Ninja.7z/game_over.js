function ToTitleScreen() {
    window.location.href = "title.html";
}
function ToMainScreen() {
    window.location.href = "main.html";
}

const score1 = sessionStorage.getItem("score") || 0;
const timePlayed1 = sessionStorage.getItem("timePlayed") || 0;
const missedFruits1 = sessionStorage.getItem("missedFruits") || 0;

console.log("Score:", score1);
console.log("Time Played:", timePlayed1);
console.log("Missed Fruits:", missedFruits1);

document.getElementById("finalScore").innerText = `Score: ${score1}`;
document.getElementById("finalTime").innerText = `Time Played: ${timePlayed1}s`;
document.getElementById("missedFruits").innerText = `Missed Fruits: ${missedFruits1}`;